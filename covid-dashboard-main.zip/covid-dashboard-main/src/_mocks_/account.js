// ----------------------------------------------------------------------

const account = {
  displayName: 'Ruchi Karn',
  email: 'ruchikrn15@gmail.com',
  photoURL: '/static/mock-images/avatars/avatar_default.jpg'
};

export default account;
